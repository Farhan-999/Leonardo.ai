
import { getServerSession } from "next-auth"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import { redirect } from "next/navigation"

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)
  if (!session) redirect("/login")

  // This would fetch real data from DB in phase 4
  const history = [
    { prompt: "a castle in the clouds", url: "/sample1.png" },
    { prompt: "cyberpunk samurai", url: "/sample2.png" },
  ]

  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Your Generations</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {history.map((item, i) => (
          <div key={i} className="border p-3 rounded-xl">
            <img src={item.url} alt="" className="rounded-md" />
            <p className="mt-2 text-sm text-gray-700">{item.prompt}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
