
import { getServerSession } from "next-auth"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import { redirect } from "next/navigation"
import PromptForm from "@/components/PromptForm"

export default async function CreatePage() {
  const session = await getServerSession(authOptions)
  if (!session) redirect("/login")
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Generate an Image</h1>
      <PromptForm />
    </div>
  )
}
