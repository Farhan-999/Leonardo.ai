
'use client'
import { useState } from 'react'

export default function PromptForm() {
  const [prompt, setPrompt] = useState('')
  const [image, setImage] = useState('')
  const [loading, setLoading] = useState(false)

  const generateImage = async () => {
    setLoading(true)
    const res = await fetch('/api/generate', {
      method: 'POST',
      body: JSON.stringify({ prompt })
    })
    const data = await res.json()
    setImage(data.url)
    setLoading(false)
  }

  return (
    <div className="space-y-4">
      <textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="Describe your image..."
        className="w-full p-3 border rounded-xl"
      />
      <button onClick={generateImage} className="px-4 py-2 bg-black text-white rounded-xl">
        {loading ? 'Generating...' : 'Generate'}
      </button>
      {image && <img src={image} alt="Generated" className="mt-4 rounded-lg shadow" />}
    </div>
  )
}
